﻿using UnityEngine;
using System.Collections;

public class TeamAttack : Moves {


	public override void MoveBehavior(){
		//trigger the team ui

	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
