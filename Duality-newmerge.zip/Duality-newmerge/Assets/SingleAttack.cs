﻿using UnityEngine;
using System.Collections;


public class SingleAttack : Moves{

	public override void MoveBehavior ()
	{
		Debug.Log ("single attack!");
	}
}
