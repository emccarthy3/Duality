﻿using UnityEngine;
using System.Collections;

public class ClassType : MonoBehaviour {
	private string className;

	public string ClassName{
		get{ return className; }
		set{ className = value; }
	}
}
